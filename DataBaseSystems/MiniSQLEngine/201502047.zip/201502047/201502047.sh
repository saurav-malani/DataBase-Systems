#!/bin/bash
LD_LIBRARY_PATH=$LD_LIBRARY_PATH:`pwd`/libs/sqlparser/
export LD_LIBRARY_PATH
./minisql "$1"
