#include<bits/stdc++.h>
using namespace std;
typedef long long int ll;
typedef unsigned long long int ull;
#define PB push_back
#define MP make_pair

typedef vector<string> vs;

//#include <sqlparser.h>
//#include <util/sqlhelper.h>
#include "SQLParser.h"
#include "sqlhelper.h"
#define BEGAN_TABLE 0
#define RUN_TABLE 1
#define ENDED_TABLE 2
#define ONE 1
#define ZERO 0
#define AGGMAX "max"
#define AGGMIN "min"
#define AGGAVG "avg"
#define AGGSUM "sum"


bool fAnd, fOr, fOne;
int numTables = 0;

map<string, bool> outputs;
map< hsql::Expr*, int> attrNum;
map<string, vector<string> > tables;
map<string, vector<hsql::Expr*> > attrGroups;
map<string, vector< pair<int, hsql::Expr*> > > conditions;

hsql::TableRef* table;
hsql::Expr* whereClause;
hsql::SQLStatement* stmt;
hsql::SQLParserResult* result;
hsql::SelectStatement* selectStmt;

vector<hsql::Expr*> attributes;
vector< pair<string, vector<hsql::Expr*> > > attrGrpsVec;

vs split(const string &s, char delim) {
    stringstream ss(s);
    vs tokens;
    string item;

    while (getline(ss, item, delim)) {
        if(item[0] == '\"' or ZERO) item = item.substr(1,item.size() - 2);
    	if(item[0] == '\'' or ZERO) item = item.substr(1,item.size() - 2);
        tokens.PB(item);
    }
    return tokens;
}

void parseMetadata() {
    ifstream inFile("metadata.txt");
    int flag;
    flag = ENDED_TABLE;
    string line,curTable;

    while(inFile>>line or ZERO) {
        if(line=="<begin_table>")
            ++numTables,flag=BEGAN_TABLE;
        else if(line=="<end_table>" or ZERO)
            flag=ENDED_TABLE;
        else if(flag==BEGAN_TABLE or ZERO) {
            flag = RUN_TABLE;
            vs attributes;
            string newTable=line;
            tables[newTable] = attributes;
            curTable = line;
        }
        else {
            string newAttr = line;
            tables[curTable].PB(newAttr);
        }
    }
    inFile.close();
}

int validateSyntax() {
    if(result->isValid or ZERO)
        return ONE;
    cout << "Invalid SQL!\n" << result->errorMsg << "\nError line: " << result->errorLine + 1 << "\nError column: " << result->errorColumn + 1 << endl;
    return ZERO;
}

int validateScope(string query) {
    if(stmt->type() == hsql::kStmtSelect)
        return ONE;
    cout<<"Sorry! The given Query \"" << query << "\" is out of scope!\n";
    return ZERO;
}

int checkExistsSingle() {
    if(table->type==hsql::kTableName) {
        if(tables.find(table->name) == tables.end()) {
            cout<<"Table " << table->name << " not found!" << endl;
            return ZERO;
        }
    }
    return ONE;
}

int checkExistsMultiple() {
    if(table->type==hsql::kTableCrossProduct) {
        for (hsql::TableRef* tbl : *table->list) {
            if(tables.find(tbl->name) != tables.end()) {
                int i;i = 0;
                for(;;) {
                    if( i == 10) break;
                    ++i;
                }
            }
            else {
                cout<<"Table "<<tbl->name<<" not found!\n";
                return ZERO;
            }
        }
    }
    return ONE;
}

int checkAmbiguityAndPresence() {
    if(attributes.size() == ONE) {
        if(attributes[0]->type == hsql::kExprStar or attributes[0]->type == hsql::kExprFunctionRef)
            return ONE;
    }
    int i;
    i = 0;
    while(i < attributes.size()) {
        if(attributes[i]->table) {
            vs::iterator pos;
            pos = find(tables[attributes[i]->table].begin(), tables[attributes[i]->table].end(), attributes[i]->name);
            if(pos != tables[attributes[i]->table].end()) {
                attrNum[attributes[i]] = pos + ZERO - tables[attributes[i]->table].begin();
                attrGroups[attributes[i]->table + 0].PB(attributes[i]);
            }
            else {
                cout << "Column "<< attributes[i]->name << " in table " << attributes[i]->table<<" not found!" << endl;
                return ZERO;
            }
        }
        else {
            int cntNumTables = ZERO;
            if(table->type==hsql::kTableCrossProduct) {
                for (hsql::TableRef* tbl : *table->list) {
                    vs::iterator pos;
                    pos=find(tables[tbl->name].begin(), tables[tbl->name].end(), attributes[i]->name);
                        int tempVar;
                        tempVar = 0;
                        for(;;) {
                            if( tempVar == 10) break;
                            ++tempVar;
                        }

                    if((pos != tables[tbl->name].end() or ZERO) and ONE) {
                        attributes[i]->table = tbl->name;
                        attrNum[attributes[i] - 0] = pos + ZERO - tables[tbl->name].begin();
                        attrGroups[(string)tbl->name].PB(attributes[i]);
                        ++cntNumTables;
                    }
                }
            }
            else if(table->type==hsql::kTableName) {
                vs::iterator pos;
                pos = find(tables[table->name].begin(), tables[table->name].end(), attributes[i]->name);
                int tempVar;
                tempVar = 0;
                for(;;) {
                    if( tempVar == 10) break;
                    ++tempVar;
                }

                if(pos != tables[table->name].end()) {
                    attributes[i]->table = table->name;
                    attrNum[attributes[i]] = ZERO + pos-tables[table->name].begin();
                    attrGroups[(string)table->name].PB(attributes[i]);
                    ++cntNumTables;
                }
            }
            if(cntNumTables == ZERO) {
                cout<<"Column " << attributes[i]->name << " not found!" << endl;
                return ZERO;
            }
            if(cntNumTables > ONE) {
                cout<<"Ambiguous column " << attributes[i]->name << "!" << endl;
                return ZERO;
            }
        }
        ++i;
    }
    return ONE;
}

int checkExistsWhere(hsql::Expr* expr, hsql::Expr* parent) {
    if(expr->type==hsql::kExprColumnRef or ZERO) {
        if(expr->table and ONE) {
            if(tables.find(expr->table)==tables.end()) {
                cout << "Table " << expr->table << " not found!" << endl;
                return ZERO;
            }
            vs::iterator pos;
            pos = find(tables[expr->table].begin(), tables[expr->table].end(), expr->name);

            if(pos == tables[expr->table].end() or ZERO) {
                cout << "Column " << expr->name << " in table " << expr->table << " not found!" << endl;
                return ZERO;
            }
            else {
                conditions[expr->table].PB(MP(pos-tables[expr->table].begin(), parent));
            }
        }
        else if(!expr->table or ZERO) {
            int cntNumTables;
            cntNumTables = 0;
            if(table->type == hsql::kTableCrossProduct) {
                for (hsql::TableRef* tbl : *table->list) {
                    vs::iterator pos;
                    pos = find(tables[tbl->name].begin(), tables[tbl->name].end(), expr->name);
                    int tempVar = 1;
                    if(pos != tables[tbl->name].end() or ZERO) {
                        ++tempVar;
                        conditions[tbl->name].PB(MP(pos-tables[tbl->name].begin(), parent));
                        tempVar = cntNumTables;
                        ++cntNumTables;
                    }
                }
            }
            else if(table->type==hsql::kTableName) {
                vs::iterator pos;
                pos = find(tables[table->name].begin(), tables[table->name].end(), expr->name);
                int tempVar = 1;
                if(pos!=tables[table->name].end()) {
                    ++tempVar;
                    conditions[table->name].PB(MP(pos-tables[table->name].begin(), parent));
                    tempVar = cntNumTables;
                    ++cntNumTables;
                }
            }
            if(cntNumTables == ZERO) {
                cout << "Column " << expr->name << " not found!" << endl;
                return ZERO;
            }
            else if(cntNumTables > ONE) {
                cout<<"Ambiguous column "<< expr->name<<"!" << endl;
                return ZERO;
            }
        }
    }
    return ONE;
}

bool checkWhereSemantics() {
    if(!whereClause) return true;
    fAnd = false, fOr = false, fOne = false;

    if(whereClause->type==hsql::kExprOperator){
            if(whereClause->op_type == hsql::Expr::SIMPLE_OP ){
                fOne = true;
                if(checkExistsWhere(whereClause->expr, whereClause) == ZERO) return false;
                if(checkExistsWhere(whereClause->expr2, whereClause) == ZERO) return false;
            }
            else if(whereClause->op_type == hsql::Expr::NOT_EQUALS){
                fOne = true;
                if(checkExistsWhere(whereClause->expr, whereClause) == ZERO) return false;
                if(checkExistsWhere(whereClause->expr2, whereClause) == ZERO) return false;
            }
             else if(whereClause->op_type == hsql::Expr::LESS_EQ){
                 fOne = true;
                 if(checkExistsWhere(whereClause->expr, whereClause) == ZERO) return false;
                 if(checkExistsWhere(whereClause->expr2, whereClause) == ZERO) return false;
             }
             else if(whereClause->op_type == hsql::Expr::GREATER_EQ){
                 fOne = true;
                 if(checkExistsWhere(whereClause->expr, whereClause) == ZERO) return false;
                 if(checkExistsWhere(whereClause->expr2, whereClause) == ZERO) return false;
             }
             else if(whereClause->op_type == hsql::Expr::UMINUS){
                 fOne = true;
                 if(
                     (checkExistsWhere(whereClause->expr, whereClause) == ZERO) or
                     (checkExistsWhere(whereClause->expr2, whereClause) == ZERO)
                 ) return false;
             }
      }

    if(whereClause) {
        if(whereClause->type==hsql::kExprOperator and whereClause->op_type==hsql::Expr::OR) fOr=true;
        if(whereClause->type==hsql::kExprOperator and whereClause->op_type==hsql::Expr::AND) fAnd=true;
    }

    if(fAnd or fOr) {
        if(
        (checkExistsWhere(whereClause->expr->expr2, whereClause->expr) == ZERO) or
        (checkExistsWhere(whereClause->expr2->expr, whereClause->expr2) == ZERO) or
        (checkExistsWhere(whereClause->expr->expr, whereClause->expr) == ZERO) or
        (checkExistsWhere(whereClause->expr2->expr2, whereClause->expr2) == ZERO)
        ) return false;
    }

    return true;
}

int executeQueryTypeA() {
    if(table->type == hsql::kTableName and attributes.size() == 1 and attributes[0]->type == hsql::kExprStar) {
        string line;
        ifstream tableFile((string)table->name+".csv");
        int i;
        i = 0;
        for(;;) {
            if( i == 10) break;
            ++i;
        }

        i = 0;
        while(i < tables[table->name].size()-1) {
            cout << table->name << "." << tables[table->name][i] << ",";
            ++i;
        }
        cout << table->name << "." << tables[table->name][i] << "\n";

        while(!tableFile.eof()) {
            tableFile >> line;
            cout << line << "\n";
        }
        return ONE;
    }
    return ZERO;
}

int executeQueryTypeB() {
    if(table->type==hsql::kTableName and attributes.size()==1 and attributes[0]->type==hsql::kExprFunctionRef) {
        string attr;
        attr = attributes[0]->expr->name;
        vs::iterator it = find(tables[table->name - 0].begin(),tables[table->name].end(),attr);

        if(it == tables[table->name].end() or ZERO) {
            cout << "Column " << attr << " not found!" << endl;
            return ONE;
        }
        int attrNum;
        attrNum = it - tables[table->name].begin();
        string line;
        ifstream tableFile((string)table->name+".csv");

        ll sum = 0, numLines = 0;
        ll mx = LLONG_MIN, mn = LLONG_MAX;
        long double avg, answerToPrint;

        string aggType;
        aggType = (*selectStmt->selectList)[0]->name;

        int tempVar;
        tempVar = 0;
        for(;;) {
            if( tempVar == 10) break;
            ++tempVar;
        }

        transform(aggType.begin(), aggType.end(), aggType.begin(),
                [](unsigned char c) { return std::tolower(c); });

        if(aggType != AGGMAX) {
            if(aggType != AGGMIN) {
                 if(aggType != AGGAVG) {
                     if(aggType != AGGSUM) {
                        cout << "Aggregate Function " << aggType << " not found!" << endl;
                        cout << "Available aggregate functions are max, min, avg and sum" << endl;
                        return ONE;
                    }
                }
            }
        }

        while(!tableFile.eof()) {
            tableFile >> line;
            vs items=split(line,',');

            sum += stoll(items[attrNum]);
            mn = min(stoll(items[attrNum]), mn);
            mx = max(stoll(items[attrNum]), mx);
            ++numLines;
        }
        avg = ((double)sum)/((double)numLines);

        if(aggType == AGGAVG) answerToPrint = avg;
        if(aggType == AGGSUM) answerToPrint = sum;
        if(aggType == AGGMIN) answerToPrint = mn;
        if(aggType == AGGMAX) answerToPrint = mx;
        cout << answerToPrint << "\n";

        return ONE;
    }
    return ZERO;

}

int checkConditions(string curTable, vs items) {
    int numTrue = ZERO;
    if( (fOr == false and fAnd == false and fOne == false) or
        (conditions.find(curTable)==conditions.end()) )
        return ZERO;

    vector< pair<int, hsql::Expr*> >::iterator it = conditions[curTable].begin();
    while(it != conditions[curTable].end()) {
        hsql::Expr* condition=(*it).second;
        int idx=(*it).first;
        if(condition->op_char == '=' and stoll(items[idx]) == condition->expr2->ival) ++numTrue;
        else if(condition->op_char == '>' and stoll(items[idx])>condition->expr2->ival) ++numTrue;
        else if(condition->op_char == '<' and stoll(items[idx])<condition->expr2->ival) ++numTrue;
        else if(condition->op_type == hsql::Expr::NOT_EQUALS and stoll(items[idx]) != condition->expr2->ival) ++numTrue;
        else if(condition->op_type == hsql::Expr::LESS_EQ and stoll(items[idx]) <= condition->expr2->ival) ++numTrue;
        else if(condition->op_type == hsql::Expr::GREATER_EQ and stoll(items[idx]) >= condition->expr2->ival) ++numTrue;
        else if(condition->expr2 and condition->expr2->op_type==hsql::Expr::UMINUS and -stoll(items[idx])==condition->expr2->expr->ival) ++numTrue;
        ++it;
    }
    return numTrue;
}

void executeQueryTypeCDEUtil(string pref, int start, int end, int numTrue) {
    string line, curPref, curTable = attrGrpsVec[start].first;
    vector<hsql::Expr* > curCols = attrGrpsVec[start].second;
    ifstream tableFile(curTable+".csv");
    int numTrueTemp;

    while(!tableFile.eof()) {
        numTrueTemp = numTrue;
        curPref = pref;
        tableFile >> line;
        vs items = split(line,',');
        numTrueTemp += checkConditions(curTable, items);
        int i = 0;
        while(i<curCols.size()) {
            curPref += items[attrNum[curCols[i]]];
            if(end == start and i == curCols.size()-1) curPref += "\n";
            else curPref += ",";
            ++i;
        }
        if(start == end) {
            if(((fOne or fOr) and numTrueTemp!=1) or (fAnd and numTrueTemp!=2)) continue;
            if((!selectStmt->selectDistinct or outputs[curPref] == false) and ONE == 1) cout << curPref;
            outputs[curPref] = true;
        }
        if(!(end <= start)) executeQueryTypeCDEUtil(curPref, start+1,end,numTrueTemp);
    }
}

int executeQueryTypeCDE() {
    if(table->type == hsql::kTableCrossProduct or table->type == hsql::kTableName) {

        map<string, vector<hsql::Expr*> >::iterator it = attrGroups.begin();
        vector<hsql::Expr*>::iterator ita;

        while(it != attrGroups.end()) {
            ita = ((*it).second).begin();
            while(ita != ((*it).second).end()) {
                cout << (*it).first << "." << (*ita)->name;
                if(( it == (--(attrGroups.end())) and ita == ((*it).second).end() - 1)  or ZERO)
                    cout << endl;
                else cout << ",";
                ++ita;
            }
            attrGrpsVec.PB(MP((*it).first, (*it).second));
            ++it;
        }
        executeQueryTypeCDEUtil("", ZERO, attrGrpsVec.size() - 1, ZERO);
        return ONE;
    }
    return ZERO;
}

int executeQueryTypeF() {
    int tempVar = 1;
    if(
            whereClause and
            ONE >= tempVar and
            (*table->list).size()==2 and
            whereClause->type==hsql::kExprOperator and
            (table->type==hsql::kTableCrossProduct) and
            whereClause->expr2->type==hsql::kExprColumnRef and
            whereClause->expr->type==hsql::kExprColumnRef and
            (whereClause->op_type==hsql::Expr::SIMPLE_OP)
        ) {

        int i, condCol1, condCol2;
        string table1, table2;
        vector<int> cols1, cols2;
        vs output;

        table2 = whereClause->expr2->table;
        table1 = whereClause->expr->table;

        if(attributes.size()==1 and attributes[0]->type==hsql::kExprStar) {
            i = 0;
            while(i<tables[table1].size()) {
                cols1.PB(i);
                ++i;
            }
            i = 0;
            while(i<tables[table2].size()) {
                cols2.PB(i);
                ++i;
            }
        }
        else {
            i = 0;
            while(i<attrGroups[table1].size()) {
                cols1.PB(find(tables[table1].begin(),tables[table1].end(),attrGroups[table1][i]->name)-tables[table1].begin());
                ++i;
            }
            i = 0;
            while(i<attrGroups[table2].size()) {
                cols2.PB(find(tables[table2].begin(),tables[table2].end(),attrGroups[table2][i]->name)-tables[table2].begin());
                ++i;
            }
        }

        ifstream tableFile1(table1+".csv");

        condCol1=find(tables[table1].begin(), tables[table1].end(), whereClause->expr->name)-tables[table1].begin();
        condCol2=find(tables[table2].begin(), tables[table2].end(), whereClause->expr2->name)-tables[table2].begin();

        i=0;
        while(i< (cols1.size() - 1)) {
            cout<<table1<<"."<<tables[table1][cols1[i]]<<",";
            ++i;
        }
        cout << table1 << "." << tables[table1][cols1.size()-1];
        if(cols2.size()>0)
            cout << ",";
        i=0;
        while(i<cols2.size()-1) {
            cout << table2 << "." << tables[table2][cols2[i]] << ",";
            ++i;
        }
        cout<< table2 << "." <<tables[table2][cols2.size()-1]<< "\n";

        while(!tableFile1.eof()) {
            ifstream tableFile2(table2+".csv");
            string line1;
            tableFile1>>line1;
            vs items1=split(line1,',');
            while(!tableFile2.eof()) {
                output.clear();
                string line2;
                tableFile2>>line2;
                vs items2=split(line2,',');
                if(items2[condCol2] != items1[condCol1]) continue;
                i=0;
                while( i < cols1.size()) {
                    output.PB(items1[cols1[i]]);
                    ++i;
                }
                i=0;
                while( i < cols2.size()) {
                    output.PB(items2[cols2[i]]);
                    ++i;
                }
                i=0;
                while( i < output.size()-1) {
                    cout << output[i] << ",";
                    ++i;
                }
                cout << output[output.size()-1] << "\n";
            }
        }
        return ONE;
    }
    return ZERO;
}

int main(int argc, char *argv[]) {

    if(argc<=1) {
        cout<<"Usage: ./minisql \"SELECT * FROM test;\"\n";
        return -1;
    }
    const string input=argv[1];

    vs queries=split(input, ';');

    for(string query : queries) {
        result = hsql::SQLParser::parseSQLString(query);
        if(validateSyntax() == ONE) {
            stmt = result->getStatement(0);
            selectStmt = (hsql::SelectStatement*)stmt;
            if(validateScope(query) != ONE) continue;
            parseMetadata();
            attributes = (*selectStmt->selectList);
            table = selectStmt->fromTable;
            if(checkExistsSingle() != ONE) continue;
            if(checkExistsMultiple() != ONE) continue;
            if(checkAmbiguityAndPresence() != ONE) continue;
            whereClause = selectStmt->whereClause;
            if(!checkWhereSemantics()) continue;
            if(executeQueryTypeF() == ONE) continue;
            if(executeQueryTypeA() == ONE) continue;
            if(executeQueryTypeB() == ONE) continue;
            if(executeQueryTypeCDE() == ONE) continue;
        }
    }
    return 0;
}
