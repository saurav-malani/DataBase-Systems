#include "BPlusTree.hpp"

#ifndef BPlusTree_cpp
#define BPlusTree_cpp
#include <iostream>
template <typename datatype>
unsigned long binarySearchUpperBound(
    const datatype& element,
    typename std::vector<datatype>::const_iterator arrayIterator,
    const unsigned long& size) {
    if (size == 1) {
        return arrayIterator[0] > element ? 0 : 1;
    } else {
        unsigned long mid = (size) / 2;
        if (arrayIterator[mid] <=
            element) {  // means upper bound is on the right side
            unsigned long newSize = size - mid;
            const typename std::vector<datatype>::const_iterator
                newArrayIterator = arrayIterator + mid;
            unsigned long upperBoundIndex =
                binarySearchUpperBound(element, newArrayIterator, newSize);
            return upperBoundIndex + mid;
        } else {
            unsigned long newSize = mid;
            const typename std::vector<datatype>::const_iterator
                newArrayIterator = arrayIterator + 0;
            unsigned long upperBoundIndex =
                binarySearchUpperBound(element, newArrayIterator, newSize);
            return upperBoundIndex;
        }
    }
}

template <typename datatype>
unsigned long binarySearchLowerBound(
    const datatype& element,
    const typename std::vector<datatype>::const_iterator arrayIterator,
    const unsigned long& size) {
    if (size == 1) {
        return arrayIterator[0] < element ? 1 : 0;
    } else {
        unsigned long mid = (size) / 2;
        if (arrayIterator[mid - 1] <
            element) {  // means upper bound is on the right side
            unsigned long newSize = size - mid;
            const typename std::vector<datatype>::const_iterator
                newArrayIterator = arrayIterator + mid;
            unsigned long lowerBoundIndex =
                binarySearchLowerBound(element, newArrayIterator, newSize);
            return lowerBoundIndex + mid;
        } else {
            unsigned long newSize = mid;
            const typename std::vector<datatype>::const_iterator
                newArrayIterator = arrayIterator + 0;
            unsigned long lowerBoundIndex =
                binarySearchLowerBound(element, newArrayIterator, newSize);
            return lowerBoundIndex;
        }
    }
}

template <typename datatype>
BPlusTree<datatype>::Node::Node(unsigned long capacity)
    : capacity(capacity), data(), children(), isLeaf(true), count(0) {}

template <typename datatype>
BPlusTree<datatype>::Node::Node(
    std::pair<std::pair<Node*, Node*>, datatype> splits)
    : capacity(splits.first.first->capacity),
      data({splits.second}),
      children({splits.first.first, splits.first.second}),
      isLeaf(false),
      count(0) {
    AdjustCount();
}


template <typename datatype>
BPlusTree<datatype>::BPlusTree(unsigned long capacity)
    : capacity(capacity), root(new Node(capacity)) {}

template <typename datatype>
bool BPlusTree<datatype>::Node::Find(const datatype& element) const {
    if (data.empty()) {
        return false;
    } else if (isLeaf) {
        unsigned long lower =
            binarySearchLowerBound(element, data.begin(), data.size());
        unsigned long upper =
            binarySearchUpperBound(element, data.begin(), data.size());
        return lower != upper;
    } else {
        unsigned long upper =
            binarySearchUpperBound(element, data.begin(), data.size());
        unsigned long lower =
            binarySearchLowerBound(element, data.begin(), data.size());
        if (lower == upper)
            return children[upper]->Find(element);
        else
            return children[lower]->Find(element) ||
                   children[lower + 1]->Find(element);
    }
}

template <typename datatype>
bool BPlusTree<datatype>::Find(const datatype& element) const {
    return root->Find(element);
}

template <typename datatype>
BPlusTree<datatype>::~BPlusTree() {
    if (root != nullptr) delete root;
}
template <typename datatype>
BPlusTree<datatype>::Node::~Node() {
    for (unsigned long i = 0; i < children.size() && !isLeaf; ++i) {
        if (children[i] != nullptr) delete children[i];
    }
}

template <typename datatype>
void BPlusTree<datatype>::Node::Insert(datatype element) {
    if (data.empty()) {
        data.push_back(element);
        children.push_back(nullptr);
        children.push_back(nullptr);
    } else if (isLeaf) {
        unsigned long upper =
            binarySearchUpperBound(element, data.begin(), data.size());
        data.insert(data.begin() + upper, element);
        children.insert(children.begin() + upper, nullptr);
    } else {
        unsigned long upper =
            binarySearchUpperBound(element, data.begin(), data.size());
        children[upper]->Insert(element);
        if (children[upper]->OverFlow()) {
            auto splits = children[upper]->Split();
            data.insert(data.begin() + upper, splits.second);
            children.insert(children.begin() + upper, nullptr);
            children[upper] = splits.first.first;
            children[upper + 1] = splits.first.second;
        }
    }
    AdjustCount();
}

template <typename datatype>
void BPlusTree<datatype>::Insert(datatype element) {
    if (root == nullptr) root = new Node(capacity);
    this->root->Insert(element);
    if (this->root->OverFlow()) {
        auto splits = this->root->Split();
        Node* temp = new Node(splits);
        root = temp;
    }
}

template <typename datatype>
std::pair<std::pair<typename BPlusTree<datatype>::Node*,
                    typename BPlusTree<datatype>::Node*>,
          datatype>
BPlusTree<datatype>::Node::Split() {
    unsigned long splitIndex = (capacity + 1) / 2 - 1;
    Node* rightNode = new Node(capacity);
    rightNode->isLeaf = isLeaf;
    datatype key = data[splitIndex];
    rightNode->data.insert(rightNode->data.begin(),
                           data.begin() + splitIndex + 1, data.end());
    rightNode->children.insert(rightNode->children.begin(),
                               children.begin() + splitIndex + 1,
                               children.end());
    data.erase(data.begin() + splitIndex, data.end());
    children.erase(children.begin() + splitIndex + 1, children.end());
    if (isLeaf) {
        children[children.size() - 1] = rightNode;
        rightNode->children.insert(rightNode->children.begin(), nullptr);
        rightNode->data.insert(rightNode->data.begin(), key);
    }
    this->AdjustCount();
    rightNode->AdjustCount();
    return std::pair<std::pair<Node*, Node*>, datatype>(
        std::pair<Node*, Node*>(this, rightNode), key);
}

template <typename datatype>
bool BPlusTree<datatype>::Node::OverFlow() const {
    return children.size() > capacity;
}

template <typename datatype>
bool BPlusTree<datatype>::Node::UnderFlow() const {
    return children.size() < (capacity + 1) / 2;
}

template <typename datatype>
bool BPlusTree<datatype>::Node::atMinCapacity() const {
    return children.size() == (capacity + 1) / 2;
}

template <typename datatype>
bool BPlusTree<datatype>::Node::atMaxCapacity() const {
    return children.size() == capacity;
}

template <typename datatype>
void BPlusTree<datatype>::Node::Merge(Node* left, datatype key, Node* right) {
    if (left->isLeaf) {
        left->data.insert(left->data.end(), right->data.begin(),
                          right->data.end());
        left->children.pop_back();
        left->children.insert(left->children.end(), right->children.begin(),
                              right->children.end());
    } else {
        left->data.push_back(key);
        left->data.insert(left->data.end(), right->data.begin(),
                          right->data.end());
        left->children.insert(left->children.end(), right->children.begin(),
                              right->children.end());
    }
    right->data.clear();
    right->children.clear();
    delete right;
    left->AdjustCount();
}

template <typename datatype>
void BPlusTree<datatype>::Node::leftShift(Node* left, datatype& key,
                                          Node* right) {
    if (left->isLeaf) {
        left->data.push_back(key);
        right->data.erase(right->data.begin());
        key = right->data[0];
        left->children.insert(left->children.begin(), nullptr);
        right->children.erase(right->children.begin());
    } else {
        left->data.push_back(key);
        key = right->data[0];
        right->data.erase(right->data.begin());
        left->children.push_back(right->children[0]);
        right->children.erase(right->children.begin());
    }
    left->AdjustCount();
    right->AdjustCount();
}

template <typename datatype>
void BPlusTree<datatype>::Node::rightShift(Node* left, datatype& key,
                                           Node* right) {
    if (left->isLeaf) {
        right->data.insert(right->data.begin(),
                           left->data[left->data.size() - 1]);
        left->data.pop_back();
        key = right->data[0];
        right->children.insert(right->children.begin(), nullptr);
        left->children.erase(left->children.begin());
    } else {
        // left->data.push_back(key);
        right->data.insert(right->data.begin(), key);
        // key = right->data[0];
        key = left->data[left->data.size() - 1];
        // right->data.erase(right->data.begin());
        left->data.pop_back();
        // left->children.push_back(right->children[0]);
        right->children.insert(right->children.begin(),
                               left->children[left->children.size() - 1]);
        left->children.pop_back();
    }
    left->AdjustCount();
    right->AdjustCount();
}

template <typename datatype>
bool BPlusTree<datatype>::Node::Delete(const datatype& key) {
    if (this->isLeaf) {
        unsigned long lower =
            binarySearchLowerBound(key, data.begin(), data.size());
        unsigned long upper =
            binarySearchUpperBound(key, data.begin(), data.size());
        if (lower != upper) {
            data.erase(data.begin() + lower);
            children.erase(children.begin() + lower);
            AdjustCount();
            return true;
        } else {
            return false;
        }
    } else {
        bool deleted = false;
        unsigned long lower =
            binarySearchLowerBound(key, data.begin(), data.size());
        unsigned long upper =
            binarySearchUpperBound(key, data.begin(), data.size());
        if (lower == upper)
            deleted = children[lower]->Delete(key);
        else {
            deleted = children[lower]->Delete(key);
            if (!deleted) {
                ++lower;
                deleted = children[lower]->Delete(key);
            }
        }
        if (children[lower]->UnderFlow()) {
            if (lower > 0 and !(children[lower - 1]->atMinCapacity())) {
                rightShift(children[lower - 1], data[lower - 1],
                           children[lower]);
            } else if (lower < (children.size() - 1) and
                       !(children[lower + 1]->atMinCapacity())) {
                leftShift(children[lower], data[lower], children[lower + 1]);
            } else {
                if (lower > 0) {
                    Merge(children[lower - 1], data[lower - 1],
                          children[lower]);
                    children.erase(children.begin() + lower);
                    data.erase(data.begin() + lower - 1);
                } else {
                    Merge(children[lower], data[lower], children[lower + 1]);
                    data.erase(data.begin() + lower);
                    children.erase(children.begin() + lower + 1);
                }
            }
        }
        AdjustCount();
        return deleted;
    }
}

template <typename datatype>
void BPlusTree<datatype>::Delete(const datatype& key) {
    root->Delete(key);
    Node* newRoot = root->NewRoot();
    if (root != newRoot) {
        delete root;
        root = newRoot;
    }
}

template <typename datatype>
typename BPlusTree<datatype>::Node* BPlusTree<datatype>::Node::NewRoot() {
    Node* newRoot = this;
    if (data.empty()) {
        newRoot = children[0];
        children.clear();
        data.clear();
    }
    return newRoot;
}
template <typename datatype>
void BPlusTree<datatype>::Node::AdjustCount() {
    if (isLeaf) {
        count = data.size();
    } else {
        count = 0;
        for (Node* child : children) {
            count += child->getCount();
        }
    }
}
template <typename datatype>
unsigned long BPlusTree<datatype>::Node::getCount() const {
    return count;
}

template <typename datatype>
unsigned long BPlusTree<datatype>::Node::getCount(datatype x,
                                                  datatype y) const {
    unsigned long lower = binarySearchLowerBound(x, data.begin(), data.size());
    unsigned long upper = binarySearchUpperBound(y, data.begin(), data.size());
    if (isLeaf) {
        return upper - lower;
    } else {
        unsigned long c = 0;
        for (unsigned long i = lower + 1; i < upper; ++i) {
            c += children[i]->getCount();
        }
        c += children[lower]->getCount(x, y);
        if (upper > lower) c += children[upper]->getCount(x, y);
        return c;
    }
}


template <typename datatype>
unsigned long BPlusTree<datatype>::GetCount(datatype x, datatype y) const {
    return root == nullptr ? 0 : root->getCount(x, y);
}

template <typename datatype>
unsigned long BPlusTree<datatype>::GetCount(datatype x) const {
    return root == nullptr ? 0 : root->getCount(x, x);
}

template <typename datatype>
unsigned long BPlusTree<datatype>::GetCount() const {
    return root == nullptr ? 0 : root->getCount();
}
#endif