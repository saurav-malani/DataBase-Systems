#ifndef Hash_hpp
#define Hash_hpp
#include <functional>
#include <iostream>
#include <vector>
template <typename datatype>
class Hash {
    const unsigned long capacity;
    class Block {
        const unsigned long capacity;
        std::vector<datatype> data;
        Block* next;
        // static Block* garbage;

      public:
        Block(unsigned long capacity);
        bool OverFlowed() const;
        bool Find(const datatype& key) const;
        bool Insert(const datatype& key);
        bool Empty() const;
        unsigned long GetHash(
            std::function<unsigned long(const datatype&)> hashFunction) const;
        std::pair<Block*, Block*> Split(
            std::function<unsigned long(const datatype&)> hashFunction);

        friend std::ostream& operator<<(std::ostream& cout, Block& block) {
            if (block.data.empty()) {
                cout << "empty";
            }
            for (datatype element : block.data) {
                cout << element << " ";
            }
            if (block.next != nullptr) {
                cout << " -> " << *(block.next);
            }
            return cout;
        }
    };
    std::vector<Block*> blocks;
    unsigned long current;
    unsigned long currentHash;
    const std::function<unsigned long(unsigned long, const datatype&)>
        hashFunction;

  public:
    Hash(unsigned long capacity,
         std::function<unsigned long(unsigned long, const datatype&)>
             hashFunction);
    bool Find(const datatype& key) const;
    void Insert(const datatype& key);
    friend std::ostream& operator<<(std::ostream& cout, Hash& hashTable) {
        for (Block* block : hashTable.blocks) {
            cout << *block << std::endl;
        }
        return cout;
    }
};
#include "Hash.cpp"
#endif