to compile run
    make;

for PART 1:B+Tree run
    ./part1 inputFile M B;


for PART 2:Linear Hashing run
    ./part2 inputFile M B;