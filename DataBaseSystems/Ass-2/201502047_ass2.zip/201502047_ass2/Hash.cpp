#include "Hash.hpp"

#ifndef Hash_cpp
#define Hash_cpp

// template <typename datatype>
// Hash<datatype>::Block::garbage = nullptr;

template <typename datatype>
Hash<datatype>::Block::Block(unsigned long capacity)
    : capacity(capacity), data(), next(nullptr) {}
template <typename datatype>
Hash<datatype>::Hash(
    unsigned long capacity,
    std::function<unsigned long(unsigned long, const datatype&)> hashFunction)
    : capacity(capacity),
      blocks({new Block(capacity), new Block(capacity)}),
      current(0),
      currentHash(0),
      hashFunction(hashFunction) {}

template <typename datatype>
bool Hash<datatype>::Find(const datatype& key) const {
    unsigned long hash = hashFunction(currentHash, key);
    if (hash < current) {
        hash = hashFunction(currentHash + 1, key);
    }
    return blocks[hash]->Find(key);
}

template <typename datatype>
bool Hash<datatype>::Block::Find(const datatype& key) const {
    for (datatype candidateKey : data) {
        if (candidateKey == key) {
            return true;
        }
    }
    return (next != nullptr ? next->Find(key) : false);
}

template <typename datatype>
bool Hash<datatype>::Block::OverFlowed() const {
    return next != nullptr;
}

template <typename datatype>
std::pair<typename Hash<datatype>::Block*, typename Hash<datatype>::Block*>
Hash<datatype>::Block::Split(
    std::function<unsigned long(const datatype&)> hashFunction) {
    std::pair<Block*, Block*> splited;
    if (next == nullptr)
        splited =
            std::pair<Block*, Block*>(new Block(capacity), new Block(capacity));
    else {
        splited = next->Split(hashFunction);
        delete next;
        next = nullptr;
    }
    for (datatype key : data) {
        unsigned long hash = hashFunction(key);
        if (splited.first->data.empty() && splited.second->data.empty()) {
            splited.first->Insert(key);
        } else if (splited.first->data.empty() &&
                   !splited.second->data.empty()) {
            if (hash == hashFunction(splited.second->data[0]))
                splited.second->Insert(key);
            else
                splited.first->Insert(key);
        } else {
            if (hash == hashFunction(splited.first->data[0]))
                splited.first->Insert(key);
            else
                splited.second->Insert(key);
        }
    }
    return splited;
}

template <typename datatype>
bool Hash<datatype>::Block::Insert(const datatype& key) {
    if (data.size() < capacity) {
        data.push_back(key);
        return false;
    } else {
        if (next == nullptr) next = new Block(capacity);
        next->Insert(key);
        return true;
    }
}

template <typename datatype>
void Hash<datatype>::Insert(const datatype& key) {
    unsigned long hash = hashFunction(currentHash, key);
    if (hash < current) hash = hashFunction(currentHash + 1, key);
    bool overFlow = blocks[hash]->Insert(key);
    if (overFlow) {
        auto spliter = [this](const datatype& key) {
            return hashFunction(currentHash + 1, key);
        };
        std::pair<Block*, Block*> splited = blocks[current]->Split(spliter);
        if ((!splited.second->Empty() &&
             splited.second->GetHash(spliter) == current) ||
            (!splited.first->Empty() &&
             splited.first->GetHash(spliter) != current))
            std::swap(splited.first, splited.second);
        delete blocks[current];
        blocks[current] = splited.first;
        blocks.push_back(splited.second);
        current++;
        if (2 * current == blocks.size()) {
            current = 0;
            currentHash++;
        }
    }
}

template <typename datatype>
unsigned long Hash<datatype>::Block::GetHash(
    std::function<unsigned long(const datatype&)> hashFunction) const {
    return hashFunction(data[0]);
}

template <typename datatype>
bool Hash<datatype>::Block::Empty() const {
    return data.empty();
}


#endif