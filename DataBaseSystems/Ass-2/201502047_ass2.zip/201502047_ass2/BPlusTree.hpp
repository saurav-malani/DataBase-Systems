#ifndef BPlusTree_hpp
#define BPlusTree_hpp
#include <iostream>
#include <utility>
#include <vector>

template <typename datatype>
class BPlusTree {
    const unsigned long capacity;
    class Node {
        std::vector<datatype> data;
        std::vector<Node*> children;
        bool isLeaf;
        const unsigned long capacity;
        unsigned long count;

      public:
        Node(unsigned long capacity);
        Node(std::pair<std::pair<Node*, Node*>, datatype> spilts);
        ~Node();
        bool Find(const datatype& element) const;
        void Insert(datatype element);
        bool Delete(const datatype& key);
        std::pair<std::pair<Node*, Node*>, datatype> Split();
        bool OverFlow() const;
        bool UnderFlow() const;
        bool atMinCapacity() const;
        bool atMaxCapacity() const;
        void AdjustCount();
        unsigned long getCount() const;
        unsigned long getCount(datatype x, datatype y) const;
        Node* NewRoot();

        static void Merge(Node* left, datatype key, Node* right);
        static void leftShift(Node* left, datatype& key, Node* right);
        static void rightShift(Node* left, datatype& key, Node* right);


        friend std::ostream& operator<<(std::ostream& cout, const Node& node) {
            cout << " { ";
            if (!node.children.empty()) {
                if (!node.isLeaf && node.children[0] != nullptr)
                    cout << *(node.children[0]);
                for (unsigned long i = 0; i < node.data.size(); ++i) {
                    cout << " " << node.data[i] << " ";
                    if (!node.isLeaf && node.children[i + 1] != nullptr)
                        cout << *(node.children[i + 1]);
                }
            }
            cout << " } ";
            return cout;
        }
    };

    Node* root;

  public:
    BPlusTree(unsigned long capacity);
    bool Find(const datatype& element) const;
    void Insert(datatype element);
    void Delete(const datatype& key);
    unsigned long GetCount() const;
    unsigned long GetCount(datatype x) const;
    unsigned long GetCount(datatype x, datatype y) const;
    ~BPlusTree();


    friend std::ostream& operator<<(std::ostream& cout, const BPlusTree& tree) {
        if (tree.root != nullptr)
            cout << *(tree.root);
        else
            cout << "empty";
        return cout;
    }
};

// Implementation File
#include "BPlusTree.cpp"
#endif