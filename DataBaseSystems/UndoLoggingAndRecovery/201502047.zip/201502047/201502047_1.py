import sys
import os
from collections import OrderedDict

database, memory = OrderedDict(), OrderedDict()
registers, id2commands = {}, {}
trans_ids = []
ans = ""

db_ops = ["READ", "WRITE", "OUTPUT"]
ops = ["+", "-", "*", "/"]

def init_value(line):
	line = line.strip().split()

	if len(line)%2==0:
		for i in range(0, len(line), 2):
			val = int(line[i+1].strip())
			database[line[i].strip()] = val
	else:
		return
	
def read(path):
	num, tid, flag = 0, None, False

	with open(path,'r') as f:
		for line in f.readlines():
			if not flag:
				init_value(line)
				flag = True
				continue

			if line.strip() == "":
				continue

			if num:
				id2commands[tid].append(line.strip())
				num -= 1
			else:
				tid, num = line.strip().split()[0].strip(), int(line.strip().split()[1].strip())
				if tid not in id2commands:
					trans_ids.append(tid)
					id2commands[tid] = []
				else:
					sys.exit("Repeated Transaction")

def output_status():
	global ans

	sort_memory = sorted(memory)
	sort_database = sorted(database)

	for i, var in enumerate(sort_memory):
		ans += "{} {}".format(var, memory[var])
		if i!=len(sort_memory) - 1:
			ans += " "
	ans += "\n"

	for i, var in enumerate(sort_database):
		ans += "{} {}".format(var, database[var])
		if i!=len(sort_database) - 1:
			ans += " "
	ans += "\n"

def db_execute(cmd, op, tid):
	global ans

	cmd = cmd[:-1].split('(')[1].strip()

	if ',' in cmd:
		var, tmp = cmd.split(',')[0].strip(), cmd.split(',')[1].strip()

	if op == "READ":
		if var not in memory:
			registers[tmp] = database[var]
			memory[var] = database[var]
		else:
			registers[tmp] = memory[var]
	
	elif op == "WRITE":
		ans += "<{}, {}, ".format(tid, var)
		if var not in memory:
			memory[var] = database[var]
		ans += "{}>\n".format(memory[var])
		memory[var] = registers[tmp]
		output_status()
	
	elif op == "OUTPUT":
		if cmd not in memory:
			memory[cmd] = database[cmd]
		else:
			database[cmd] = memory[cmd]

def check(inp):
	try:
		return int(inp)
	except:
		return registers[inp]

def arith_execute(c, a, b, op):
	a, b = check(a), check(b)

	if op == "-":
		registers[c] = a - b

	elif op == "+":
		registers[c] = a + b

	elif op == "*":
		registers[c] = a * b

	elif op == "/":
		if b==0:
			sys.exit("Divide by zero")
		registers[c] = a / b
	

def execute(tid, start, end):
	for i in range(start, end):
		cmd = id2commands[tid][i]
		flag = False

		for op in db_ops:
			if op in cmd:
				db_execute(cmd, op, tid)
				flag = True
				break
		if flag:
			continue

		cmd = cmd.strip().split(":=")

		c = cmd[0].strip()

		for op in ops:
			if op in cmd[1].strip():
				a, b = cmd[1].strip().split(op)[0].strip(), cmd[1].strip().split(op)[1].strip()
				arith_execute(c, a, b, op)
				break

def calc(x):
	l = 0
	global ans

	while True:
		cnt = 0
		start = l * x
		for i in range(len(trans_ids)):
			num = len(id2commands[trans_ids[i]])

			if start == 0:
				ans += "<START {}>\n".format(trans_ids[i])
				output_status()

			if num <= start:
				cnt+=1
				continue
			
			end = min((l+1)*x, num)
			execute(trans_ids[i], start, end)

			if end == num:
				ans += "<COMMIT {}>\n".format(trans_ids[i])
				output_status()

		l += 1

		if cnt != len(trans_ids):
			continue
		else:
			break

if __name__ == "__main__":
	path, x = sys.argv[1], int(sys.argv[2])
	read(path)
	calc(x)
	with open("20161024_1.txt","w") as f:
		f.write(ans)