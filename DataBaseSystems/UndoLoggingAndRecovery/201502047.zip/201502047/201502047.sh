#!/bin/sh
if [ "$#" -ne 1 ]; then
    python 201502047_1.py $1 $2
else 
    python 201502047_2.py $1
fi
